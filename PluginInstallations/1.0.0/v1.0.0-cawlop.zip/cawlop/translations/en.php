<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{cawlop}prestashop>cawlop_a9928cf14ad15878c88657a133832f4b'] = 'This module offers a 1-click integration to start accepting payments with the Cawl Direct APIs (former Ingenico-Ogone). Grow your revenues by offering your customers with global and regional payment methods to sell across Europe.';
$_MODULE['<{cawlop}prestashop>advancedsettingsupdater_9a2dda2e822a0b696c747714dc396a36'] = 'Error while uploading logo';
$_MODULE['<{cawlop}prestashop>paymentmethodssettingsupdater_9a2dda2e822a0b696c747714dc396a36'] = 'Error while uploading the logo';
$_MODULE['<{cawlop}prestashop>paymentmethodsvalidationdata_7f11141dcf0805c283ec31580c13c6f0'] = 'Please fill a valid iframe template filename (Eg. Filename.html)';
$_MODULE['<{cawlop}prestashop>paymentmethodsvalidationdata_807287a94a5b9c2acad32e32fa7966f9'] = 'Please fill a valid iframe template filename (Eg. Filename.html)';
$_MODULE['<{cawlop}prestashop>_account_4d5affc0cf00aa4491eb8f0fcade26c8'] = '> Login to the Ingenico Back Office. Go to Configuration > Technical information > Ingenico Direct Settings > Direct API Key';
$_MODULE['<{cawlop}prestashop>_account_bb29639e1609579b384863eebae33fc5'] = 'To retrieve the webhooks credentials, login to the Ingenico Back Office.';
$_MODULE['<{cawlop}prestashop>_paymentmethodssettings_002c18d9b9b0bcb5eb2888cdfeb6373a'] = 'A unique pay button to be redirected to pay on a Cawl hosted page';
$_MODULE['<{cawlop}prestashop>_paymentmethodssettings_df2a60fbc299477de52630ae7fe6e477'] = 'Each payment method identified by a button. On click, customer is redirected to pay on the brand specific payment page';
$_MODULE['<{cawlop}prestashop>_whatsnew_bf94bb27e01b50f305eb2cd7eeee3fff'] = 'Automatic update of available payment methods';
$_MODULE['<{cawlop}prestashop>_whatsnew_7c83c5af9f8757a8f3ca62f847af6263'] = 'Improvements in the following work steps';
$_MODULE['<{cawlop}prestashop>_whatsnew_82fa2b0be155e54abc1aa10f10c501ea'] = 'Easy to use split order management/multi-shipment';
$_MODULE['<{cawlop}prestashop>_whatsnew_e051c855c860234bc684044983fa422e'] = 'Dynamic feedback retrieval – if no feedback is received on a transaction, the plugin queries it itself !';
